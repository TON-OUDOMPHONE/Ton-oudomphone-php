<!doctype html>
<html lang="en">

    <body>
       welcome <?php
       echo $_POST["name"];       ?>
       Your email address is: <?php echo $_POST["email"];?>
    </body>
</html>
