<<!doctype html>
<html lang="en">
    <body>
        <script>declare(strict_types = 1)</script>
      <?php 
      
      /*
      function familyName($fname){
        echo "$fname Resfsnes.<br>";
      }
      familyName("Jani");
      familyName("hege");
      familyName("Stale");
      familyName("Kai Jim");
      familyName("Borge");
      
      function add_five(&$value){
        $value +=5;
      }
      $num = 2;
      add_five($num);
      echo $num
      
      function sumMynumber(...$x){
        $n = 0;
        $len = count($x);
        for ($i = 0; $i < $len; $i++){
            $n += $x[$i];
        }
        return $n;
      }
      $a = sumMynumber(5,2,6,2,7,7);
      echo $a
      
      function addNumbers(int $a,  int $b){
        return $a + $b;
      }
      echo addNumbers(1.5,5.2)
      
      $scars = array("volvo","BMV","Toyota");
      print_r($scars);
      $scar = ["volvo","BMV","Toyota"];
      print_r($scar);
      $cars = [
        "volvo",
        "BMV",
        "Toyota"
      ];
      print_r($cars);
    
    $cars = [
        0 => "Volvo",
        1 => "BMV",
        2 => "Toyota"
    ];
    print_r($cars);
    $sars = []; 
    $sars[0] = "volvo";
    $sars[1] = "BMV";
    $sars[2] = "Toyota";
    print_r($sars)
    
    $myArr = [];
    $myArr[0] = "apples";
    $myArr[1] = "bananas";
    $myArr["fruit"] = "cherries";
    print_r($myArr)
    
    $fruit = array("Apple", "Bakana","Cherry");
    $fruit[] = "organe";
    print_r($fruit);
    $cars = array("brand"=> "ford", "model" => "mustang");
    $cars["color"] = "red";
    print_r($cars);
    
    $fruits = array("apple", " bakana","cherry");
    array_push($fruits, "organe","kiwi","lemon");
    print_r($fruits);
    $cars = array("brand" => "ford","model"=> "f150");
    $cars += ["color"=> "red","ban mo rong"=> "4x4", " kem goi ro mooc"=> "chuyen nghiep"];
    print_r($cars);
    
    $cars = array("brand", "ford","model", "f150");
    array_splice($cars,1,1);
    echo $cars[0],",",$cars[1];
    
    $cars = array("Volvo", "BMV","Toyota");
    unset($cars[1]);
    echo $cars[0],",",$cars[2],"\n";
    echo $cars[0],",",$cars[1];
    
    $x =75;
    function myfunction(){
        global $x;
        echo $GLOBALS['x'];
        echo "<br>".$x;
    }
    myfunction();
    
    echo $_SERVER['PHP_SELF'];
    echo "<br>";
    echo $_SERVER['SERVER_NAME'];
    echo "<br>";
    echo $_SERVER['HTTP_HOST'];
    echo "<br>";
    echo $_SERVER['HTTP_REFERER'];
    echo "<br>";
    echo $_SERVER['HTTP_USER_AGENT'];
    echo "<br>";
    echo $_SERVER['SCRIPT_NAME'];
    
    $str = "Visit Hanoi city";
    $pattern = "/Hanoi/i";
    echo preg_match($pattern, $str);
    echo "<br>";
    $str = " the rain in spain falls mainly on the plains";
    $pattern = "/ain/i";
    echo preg_match_all($pattern, $str);
    echo "<br>";
    $str = "visit microsoft";
    $pattern = "/microsoft/i";
    echo preg_replace($pattern, "Hanoi", $str);
    */
    
      ?>
    </body>
</html>
