<!DOCTYPE html>
<html>
    <head>
        <title>Customer</title>
    </head>
    <body>
        Xin chào bạn {{$name}}
    </body>
</html>