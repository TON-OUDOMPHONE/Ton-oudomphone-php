<!DOCTYPE html>
<html>
    <head>
        <title>Customer</title>
    </head>
    <body>
        Đây là trang Customer !
    </body>
</html>