<?php
//trong 3 file có 3 lớp và buộc lớp phải trùng tên file
require_once"./MVC/processing/Application.php";
require_once"./MVC/processing/Controllers.php";
require_once"./MVC/processing/DBManager.php"
?>  